-- Insert sample data
INSERT INTO users (username, email, signup_date) VALUES
('Eric', 'eric@gmail.com', '2024-01-01'),
('Jane', 'jane@gmail.com', '2024-02-01');

INSERT INTO artists (name, genre) VALUES
('Burna Boy', 'Afrobeat'),
('Drake', 'Hip Hop');

INSERT INTO songs (title, artist_id, release_year) VALUES
('Last Last', 1, 2022),
('Gods Plan', 2, 2018);

INSERT INTO favorites (user_id, song_id) VALUES
(1,1),(1,2),(2,2);

-- Query favorites
SELECT u.username, s.title
FROM favorites f
JOIN users u ON f.user_id = u.user_id
JOIN songs s ON f.song_id = s.song_id;

-- Songs by artist
SELECT a.name, s.title
FROM songs s
JOIN artists a ON s.artist_id = a.artist_id;

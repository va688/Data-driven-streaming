# Data Dictionary

## users
- user_id (PK)
- username
- email
- signup_date

## artists
- artist_id (PK)
- name
- genre

## songs
- song_id (PK)
- title
- artist_id (FK)
- release_year

## favorites
- fav_id (PK)
- user_id (FK)
- song_id (FK)
- liked_at

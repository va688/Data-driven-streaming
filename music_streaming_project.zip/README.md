# Music Streaming Database Project

## Overview
This project models a backend database for a music streaming platform.

## Features
- User management
- Artist and song catalog
- Favorites tracking
- Analytical queries

## Tech Stack
- PostgreSQL (Supabase compatible)
- SQL

## Files Included
- schema.sql
- queries.sql
- data_dictionary.md
- ERD.png
- screenshots/

## How to Use
1. Run schema.sql
2. Insert sample data
3. Run queries.sql

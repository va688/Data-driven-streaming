-- USERS
CREATE TABLE users (
    user_id SERIAL PRIMARY KEY,
    username VARCHAR(50),
    email VARCHAR(100) UNIQUE,
    signup_date DATE
);

-- ARTISTS
CREATE TABLE artists (
    artist_id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    genre VARCHAR(50)
);

-- SONGS
CREATE TABLE songs (
    song_id SERIAL PRIMARY KEY,
    title VARCHAR(150),
    artist_id INT REFERENCES artists(artist_id),
    release_year INT
);

-- FAVORITES
CREATE TABLE favorites (
    fav_id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(user_id),
    song_id INT REFERENCES songs(song_id),
    liked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
